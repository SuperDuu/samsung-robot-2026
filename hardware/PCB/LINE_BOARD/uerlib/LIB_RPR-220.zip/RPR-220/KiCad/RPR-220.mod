PCBNEW-LibModule-V1  2026-10-05 09:56:03
# encoding utf-8
Units mm
$INDEX
RPR220
$EndINDEX
$MODULE RPR220
Po 0 0 0 15 6ac36623 00000000 ~~
Li RPR220
Cd RPR-220-4
Kw Undefined or Miscellaneous
Sc 0
At STD
AR 
Op 0 0 0
T0 1.400 -1.25 1.27 1.27 0 0.254 N V 21 N "U**"
T1 1.400 -1.25 1.27 1.27 0 0.254 N I 21 N "RPR220"
DS -1.8 1.2 4.6 1.2 0.1 24
DS 4.6 1.2 4.6 -3.7 0.1 24
DS 4.6 -3.7 -1.8 -3.7 0.1 24
DS -1.8 -3.7 -1.8 1.2 0.1 24
DS -2.8 2.2 5.6 2.2 0.1 24
DS 5.6 2.2 5.6 -4.7 0.1 24
DS 5.6 -4.7 -2.8 -4.7 0.1 24
DS -2.8 -4.7 -2.8 2.2 0.1 24
DS -1.8 1.2 4.6 1.2 0.2 21
DS 4.6 1.2 4.6 -3.7 0.2 21
DS 4.6 -3.7 -1.8 -3.7 0.2 21
DS -1.8 -3.7 -1.8 1.2 0.2 21
DS -2.3 -0 -2.3 -0 0.1 21
DS -2.4 -0 -2.4 -0 0.1 21
DA -2.35 -0 -2.300 -0 -1800 0.1 21
DA -2.35 -0 -2.400 -0 -1800 0.1 21
$PAD
Po 0.000 -0
Sh "1" R 1.416 1.416 0 0 900
Dr 0.91 0 0
At STD N 00E0FFFF
Ne 0 ""
$EndPAD
$PAD
Po 0.000 -2.5
Sh "2" C 1.416 1.416 0 0 900
Dr 0.91 0 0
At STD N 00E0FFFF
Ne 0 ""
$EndPAD
$PAD
Po 2.800 -2.5
Sh "3" C 1.416 1.416 0 0 900
Dr 0.91 0 0
At STD N 00E0FFFF
Ne 0 ""
$EndPAD
$PAD
Po 2.800 -0
Sh "4" C 1.416 1.416 0 0 900
Dr 0.91 0 0
At STD N 00E0FFFF
Ne 0 ""
$EndPAD
$EndMODULE RPR220
$EndLIBRARY
